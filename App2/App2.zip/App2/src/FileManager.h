//
// Created by Angelo on 8/10/2020.
//

#ifndef APP2_FILEMANAGER_H
#define APP2_FILEMANAGER_H

#include "ISaveRead.h"

class FileManager {
public:
    static void deserialize(ISaveRead*, VectorPerson&);

};



#endif //APP2_FILEMANAGER_H
