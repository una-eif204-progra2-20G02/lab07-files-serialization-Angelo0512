#include <iostream>
#include "FileManager.h"
#include "ReadPersonJson.h"


int main() {


    VectorPerson personsArray;
    ISaveRead* read = new ReadPersonJson();
    FileManager::deserialize(read, personsArray);

    std::cout << personsArray.toString() << std::endl;

    delete read;
    return 0;
}
