//
// Created by Angelo on 8/10/2020.
//

#ifndef APP2_READPERSONJSON_H
#define APP2_READPERSONJSON_H

#include "../lib/nlohmann/json.hpp"
#include "ISaveRead.h"

using json = nlohmann::json;

class ReadPersonJson : public ISaveRead{

public:
    void load(VectorPerson&) override;

    static Person deserPerson(json);

    static vector<Person> convertToObject(const json&);

    ~ReadPersonJson() override;
};
#endif //APP2_READPERSONJSON_H
