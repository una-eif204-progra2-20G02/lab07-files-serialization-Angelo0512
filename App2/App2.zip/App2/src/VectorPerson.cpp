//
// Created by Angelo on 8/10/2020.
//

#include "VectorPerson.h"

void VectorPerson::addPerson(Person person1){ Persons.emplace_back(person1); }

string VectorPerson::toString(){
    ostringstream output;
    for(auto & Person : Persons)
        output<<Person.toString() << endl;
    return output.str();
}

int VectorPerson::size() { return Persons.size(); }

VectorPerson::~VectorPerson(){ Persons.clear(); }

Person VectorPerson::getPerson(int position) { return Persons[position]; }

VectorPerson::VectorPerson(vector<struct Person> vector) { Persons = std::move(vector); }

VectorPerson::VectorPerson() {

}