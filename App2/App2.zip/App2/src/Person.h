//
// Created by Angelo on 8/10/2020.
//

#ifndef APP2_PERSON_H
#define APP2_PERSON_H

#include <iostream>
#include <sstream>

using namespace std;

class Person {
private:
    int id{};
    int age{};
    string name;
public:

    Person();

    Person(int id, int age, string name);

    virtual ~Person();

    int getId() const;

    void setId(int id);

    int getAge() const;

    void setAge(int age);

    const string &getName() const;

    void setName(const string &name);

    string toString() const;
};


#endif //APP2_PERSON_H
