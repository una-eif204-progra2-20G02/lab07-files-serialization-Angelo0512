//
// Created by Angelo on 8/10/2020.
//

#include "FileManager.h"

void FileManager::deserialize(ISaveRead * typeDeserial, VectorPerson& array) {
    typeDeserial->load(array);
}