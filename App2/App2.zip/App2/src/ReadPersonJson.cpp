//
// Created by Angelo on 8/10/2020.
//

#include "ReadPersonJson.h"
#include <fstream>



void ReadPersonJson::load(VectorPerson& arrayPers){
    ifstream archivo;
    json vector;
    try { archivo.open("PersonJsonFile.txt", ios::binary); }
    catch (ifstream::failure a) { exit(1);}

    archivo>>vector;
    arrayPers = convertToObject(vector);
}

Person ReadPersonJson::deserPerson(json array) {
    Person person1;

    person1.setId(array["Id"]);
    person1.setAge(array["Age"]);
    person1.setName(array["Name"]);

    return person1;
}

vector<Person> ReadPersonJson::convertToObject(const json& array) {

    vector<Person> arrayAuxPerson;
    vector<json> arrayAuxJson = array;
    Person personAux;
    for(auto & i : arrayAuxJson){
        personAux = deserPerson(i);
        arrayAuxPerson.push_back(personAux);
    }
    return arrayAuxPerson;
}

ReadPersonJson::~ReadPersonJson() = default;