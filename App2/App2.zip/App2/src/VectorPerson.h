//
// Created by Angelo on 8/10/2020.
//

#ifndef APP2_VECTORPERSON_H
#define APP2_VECTORPERSON_H

#include "Person.h"
#include <vector>

class VectorPerson {
private:
    vector<Person> Persons;
public:
    void addPerson(Person);

    int size();

    string toString();

    ~VectorPerson();

    Person getPerson(int position);

    VectorPerson(vector<struct Person> vector);

    VectorPerson();
};


#endif //APP2_VECTORPERSON_H
