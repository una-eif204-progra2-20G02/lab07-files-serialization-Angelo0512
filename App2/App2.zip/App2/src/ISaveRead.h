//
// Created by Angelo on 8/10/2020.
//

#ifndef APP2_ISAVEREAD_H
#define APP2_ISAVEREAD_H

#include "VectorPerson.h"
#include <sstream>

class ISaveRead {
public:
    virtual ~ISaveRead(){};
    virtual void load(VectorPerson&) = 0;
};
#endif //APP2_ISAVEREAD_H
